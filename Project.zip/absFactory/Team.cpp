#include "Team.h"

Team::Team(Location* loc, string name, string season) {
    this->teamName = name;
    this->season = season;
	//strategist
    strategist = new Strategist("John Murphy", loc);
    strategist->formulateStrategy();
	//engineers
    engineers= new Engineer*[4]; // in a team there are 4 main engineers
    engineers[0]=new Engineer("Aerodynamics Department","Mpho Vilakazi");
    engineers[1]=new Engineer("Engine Department","Thato Ndlovu");
    engineers[2]=new Engineer("Electronics  Department","Mike Smith");
    engineers[3]=new Engineer("Chassis Department","Bob Ncube");
   //drivers
	drivers= new Driver*[2];
	drivers[0]= new Driver(name+" driver1.");
	drivers[1]= new Driver(name+" driver2.");
    
    // equipement
    Equipment[0] = "Cockpits";
    Equipment[1] = "Halmets";
    Equipment[2] = "Racing Kits";
    Equipment[3] = "Tire Warmers";
    Equipment[4] = "Clocks/Stopwatches";
      pitcrew= new PitCrew();
	
	
}

Team::Team(string name, string season)
{
	 this->teamName = name;
    this->season = season;
	//engineers
    engineers= new Engineer*[4]; // in a team there are 4 main engineers
    engineers[0]=new Engineer("Aerodynamics Department","Mpho Vilakazi");
    engineers[1]=new Engineer("Engine Department","Thato Ndlovu");
    engineers[2]=new Engineer("Electronics  Department","Mike Smith");
    engineers[3]=new Engineer("Chassis Department","Bob Ncube");
   //drivers
	drivers= new Driver*[2];
	drivers[0]= new Driver(name+" driver1.");
	drivers[1]= new Driver(name+" driver2.");
    
    // equipement
    Equipment[0] = "Cockpits";
    Equipment[1] = "Halmets";
    Equipment[2] = "Racing Kits";
    Equipment[3] = "Tire Warmers";
    Equipment[4] = "Clocks/Stopwatches";
	
   pitcrew= new PitCrew();
	
}

void Team:: createStrategist(Location* loc)
{
	//strategist
    strategist = new Strategist("John Murphy", loc);
    strategist->formulateStrategy();
}

Team::~Team()
{
	for(int i=0;i<4;i++)
	{
		delete engineers[i];
	}
	delete engineers;
	
	for(int i=0;i<2;i++)
	{
		delete drivers[i];
	}
	delete drivers;
	
	for(int i=0;i<2;i++)
	{
		delete cars[i];
	}
	delete cars;
	
	//delete pitcrew;
	delete strategist;
	//delete truck;
	
}


string Team::getName() {
    return this->teamName;
}

Vehicle** Team::getCars(){
    return cars;
}

Driver** Team::getDrivers(){
    return drivers;
}

void Team::setCars(Vehicle** v){
    cars = v;
}

void Team::setDrivers(Driver** d){
    drivers = d;
}

Vehicle* Team::getCar1()
{
	return cars[0];
}
Driver* Team::getDriverAt(int index)
{
	return drivers[index];
}
Vehicle* Team::getCar2()
{
	return cars[1];
}
Vehicle* Team::getCarAt(int index)
{
	return cars[index];
}
void Team::setPit(PitCrew* p)
{
     pitcrew = p;
}

PitCrew* Team::getPit()
{
     return pitcrew;
}

Strategist* Team::getStrategist()
{
     return strategist;
}

void Team::notify()
{
  cout<<teamName+" has finished simulating"<<endl;
}