#include "Decorator.h"

Decorator ::Decorator()
{
	
}
Decorator ::~Decorator()
{
	delete c;
	delete racetrack;
}
void Decorator ::makeRaceTrack()
{
	RaceTrack* _racetrack = new BasicRaceTrack();
	this->racetrack=_racetrack;
}
void Decorator ::makeCompound(string weather)
{
	Compound* _c = new Compound(weather);
	this->c=_c;
}
void Decorator ::useCompound()
{
	if(c->getWeather()=="sunny")
	{
		BasicRaceTrack* s = new BasicRaceTrack();
		racetrack=s;
	}
	else if(c->getWeather()=="rainy")
	{
		BasicRaceTrack* s = new BasicRaceTrack();
		racetrack=s;
	}
	else if(c->getWeather()=="cloudy")
	{
		BasicRaceTrack* s = new BasicRaceTrack();
		racetrack=s;
	}
}
void Decorator ::print()
{
	//cout<<racetrack->operation()<<endl;
}

string Decorator:: getRaceTrackName()
{
	return racetrack->getRaceTrackkName();
	
}


string  Decorator:: getTyreCompound()
{
	return racetrack->getTyreCompound();
	
}
	
		
	
		




