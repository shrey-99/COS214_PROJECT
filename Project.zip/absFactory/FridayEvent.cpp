#include "FridayEvent.h"

FridayEvent::FridayEvent(string name) : Event(name) {
	// cout << "Friday Event Created." << endl;
}

void FridayEvent::performEvent() {
	cout << "                               " << endl;
	cout << "                               " << endl;
	cout << "//////////////////////////////////////////////////////////////////////////////////////////" << endl;
	 cout << "Lets Begin The Friday Event." << endl;
	cout << "Lets Send All The Drivers and Cars Into The Simulator and WindTunnel." << endl;
	cout << "//////////////////////////////////////////////////////////////////////////////////////////" << endl;
	vector<Team*> team=this->getTeam();
	for (auto it : team) 
	{ 
		this->simulator(it);
	} 
  //  this->windTunnel();
	cout << "                               " << endl;
	cout << "//////////////////////////////////////////////////////////////////////////////////////////" << endl;
	 cout << "We Have Completed The Friday Event." << endl;
	cout << "//////////////////////////////////////////////////////////////////////////////////////////" << endl;
	cout << "                               " << endl;
	cout << "                               " << endl;
	cout << "                               " << endl;
}

void FridayEvent::simulator(Team*t) {
    cout << "***********************************************************" << endl;
    cout << "The simulator has turned on" << endl;
    cout << "Team: "+t->getName()+" is using the simulator"<< endl;
    Driver** d = t->getDrivers();
    Vehicle** c = t->getCars();
	
    int lp =c[0]->calculateTime();
    cout << "Driver 1:  "+d[0]->getName()+" has laptime "+ to_string(lp)+ "s"<< endl;
    cout << "Sending to car 1 to windTunnel"<<endl;
    windTunnel(c[0]);
    cout<<endl;

   int lp2 = c[1]->calculateTime();
    cout << "Driver 2:  "+d[1]->getName()+" has laptime "+ to_string(lp2)+ "s"<< endl;
    cout << "Sending to car 2 to windTunnel"<<endl;
    windTunnel(c[1]);
    cout<<endl;

    t->notify();
    cout << "***********************************************************" << endl;
  //  cout << "Driver 2:  "+d[2]->getName()+" has laptime "+c[1]->calculateTime()+<< endl;
}

void FridayEvent::windTunnel(Vehicle*v) {
    v->increaseSpecs();
    cout << "The windtunned was used" << endl;
}

void FridayEvent:: printIterator()
{
	
	
}