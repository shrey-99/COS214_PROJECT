#include "Engineer.h"

Engineer::Engineer() // default constructor 
{
	
}

Engineer::Engineer(string d, string n) // constructor 
{
	name = n;
	department = d;
}

Engineer::~Engineer() 
{
	
}