#ifndef TEAM_H
#define TEAM_H

#include <string>
#include "Driver.h"
#include "Engineer.h"
#include "observer.h"
#include "Vehicle.h"
#include "Location.h"
#include "Strategist.h"
#include "PitCrew.h"

using namespace std;

class Team {
private:
    string teamName;
    string season;
    Engineer** engineers; //engineers   in a team there are 4 main engineers
    PitCrew* pitcrew;//pitCrew
    Strategist* strategist; //strategist
    Vehicle** cars;//vehicle
    Vehicle* truck;
    string Equipment[5]; 
    Driver** drivers;

public:
     Team(string, string);
    Team(Location*, string, string);
    ~Team();
    string getName();
    Vehicle** getCars();
    Driver** getDrivers();
    void setCars(Vehicle**);
    void setDrivers(Driver**);
    Vehicle* getCar1();
   Vehicle* getCar2();
 Driver* getDriverAt(int);
Vehicle* getCarAt(int);
   PitCrew* getPit();
   void setPit(PitCrew*);
   virtual void notify();
   void createStrategist(Location* loc);
   Strategist* getStrategist();

};
 
#endif
