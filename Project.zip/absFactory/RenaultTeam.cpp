#include "RenaultTeam.h"

RenaultTeam::RenaultTeam() : Team("Renault", "1") {

}