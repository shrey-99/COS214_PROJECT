#include "GrandPrix.h"

GrandPrix::GrandPrix() 
{
	cout<<"Created A Grand Prix."<<endl;
	events = new Event*[3];
	
	AlphaRomeoTeamCreator* fact1 = new AlphaRomeoTeamCreator();
	AlphaTauriTeamCreator* fact2 = new AlphaTauriTeamCreator();
	FerrariTeamCreator* fact3 = new FerrariTeamCreator();
	HaasTeamCreator* fact4 = new HaasTeamCreator();
	MclarenTeamCreator* fact5 = new MclarenTeamCreator();
	//MercedesTeamCreator* fact6 = new MercedesTeamCreator();
	RacingPointTeamCreator* fact7 = new RacingPointTeamCreator();
	RedBullTeamCreator* fact8 = new RedBullTeamCreator();
	RenaultTeamCreator* fact9 = new RenaultTeamCreator();
	WilliamsTeamCreator* fact10 = new WilliamsTeamCreator();
	
	Team* team1 = fact1->createTeam();
	Team* team2 = fact2->createTeam();
	Team* team3 = fact3->createTeam();
	Team* team4 = fact4->createTeam();
	Team* team5 = fact5->createTeam();
	//Team* team6 = fact6->createTeam();
	Team* team7 = fact7->createTeam();
	Team* team8 = fact8->createTeam();
	Team* team9 = fact9->createTeam();
	Team* team10 = fact10->createTeam();
	
	//cout<<"Success."<<endl;
	
	Vehicle** cars1 = fact1->createRaceCar();
	Vehicle** cars2 = fact2->createRaceCar();
	Vehicle** cars3 = fact3->createRaceCar();
	Vehicle** cars4 = fact4->createRaceCar();
	Vehicle** cars5 = fact5->createRaceCar();
	//Vehicle** cars6 = fact6->createRaceCar();
	Vehicle** cars7 = fact7->createRaceCar();
	Vehicle** cars8 = fact8->createRaceCar();
	Vehicle** cars9 = fact9->createRaceCar();
	Vehicle** cars10 = fact10->createRaceCar();
	
	team1->setCars(cars1);
	team2->setCars(cars2);
	team3->setCars(cars3);
	team4->setCars(cars4);
	team5->setCars(cars5);
	//team6->setCars(cars6);
	team7->setCars(cars7);
	team8->setCars(cars8);
	team9->setCars(cars9);
	team10->setCars(cars10);
	
	//cout<<"Success."<<endl;
	
	events[0]= new FridayEvent("Grand Prix");
	events[1]= new SaturdayEvent("Grand Prix");
	events[2]= new SundayEvent("Grand Prix");
	
	vector<Team*> teams1=events[0]->getTeam();
	vector<Team*> teams2=events[1]->getTeam();
	vector<Team*> teams3=events[2]->getTeam();
	
	teams1.push_back(team1);
	teams1.push_back(team2);
	teams1.push_back(team3);
	teams1.push_back(team4);
	teams1.push_back(team5);
	///teams1.push_back(team6);
	teams1.push_back(team7);
	teams1.push_back(team8);
	teams1.push_back(team9);
	teams1.push_back(team10);
	
	teams3.push_back(team1);
	teams3.push_back(team2);
	teams3.push_back(team3);
	teams3.push_back(team4);
	teams3.push_back(team5);
	//teams3.push_back(team6);
	teams3.push_back(team7);
	teams3.push_back(team8);
	teams3.push_back(team9);
	teams3.push_back(team10);
	//cout<<"Success."<<endl;
	
	teams2.push_back(team1);
	teams2.push_back(team2);
	teams2.push_back(team3);
	teams2.push_back(team4);
	teams2.push_back(team5);
	//teams2.push_back(team6);
	teams2.push_back(team7);
	teams2.push_back(team8);
	teams2.push_back(team9);
	teams2.push_back(team10);
	
	events[0]->setTeam(teams1);
	events[1]->setTeam(teams2);
	events[2]->setTeam(teams3);
	
	flags[0]="Green Flag : Begin Race.";
	flags[1]="Yellow Flag : Hazard!!!.";
	flags[2]="Black Flag : Return To PitStop.";
	flags[3]="Checkered Flag : End Race.";
	flags[4]="Code60 Flag : ";
	flags[5]="Blue Flag : Courtesy Passing.";
	flags[6]="White Flag : ";
	flags[7]="Red Flag : ";
	
	
	delete fact1;
	delete fact2 ;
	delete fact3;
	delete fact4;
	delete fact5;
	//delete fact6;
	delete fact7;
	delete fact8;
	delete fact9;
	delete fact10;
	
	
}

GrandPrix:: ~GrandPrix() 
{
	 cout<<"Grand Prix Deleted."<<endl;
	delete location;
}

void GrandPrix ::setLocation(Location* location)
{
	this->location=location;
	
	vector<Team*> teams3=events[0]->getTeam();
	vector<Team*> teams4=events[1]->getTeam();
	
	
	for (auto it : teams3) { 
	it->createStrategist(location);
	Strategist* holder=it->getStrategist();
	holder->formulateStrategy();
	}
		
	for (auto it2 : teams4) { 
	it2->createStrategist(location);
	Strategist* holder=it2->getStrategist();
	holder->formulateStrategy();
	
    } 
	
}

Event** GrandPrix ::getEvents()
{
    return events;
}

string GrandPrix :: FlagAt(int index)
{
	return flags[index];
}
