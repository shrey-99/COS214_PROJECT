#ifndef ALPHAROMEOTEAM_H
#define ALPHAROMEOTEAM_H

#include "Team.h"

using namespace std;

class AlphaRomeoTeam : public Team {
public:
    AlphaRomeoTeam();
};

#endif