#include "PitCrew.h"

/*
  * code something to minus fuel (in race() )
  * if damage 0; check inside race(); give 0 points; i.e last place 

*/


void PitCrew::checkVehicle(){
   cout<<"Checking Car"<<endl;
 
    if (car->getFuel() <=20){
      refuel();
    }
    else{
      changeTyre();
    }
  
}
void PitCrew::getcar(RaceCar*c){\
  car = c;
}

void PitCrew::refuel(){
	cout<<"refueling Car"<<endl;
  car->setFuel(car->getFuel() +10);
  int newD = car->getFuel()/car->getTyreWare();
  car->setDamage(newD);
}

void PitCrew::changeTyre(){
	cout<<"Changing Car Tyres"<<endl;
  car->setTyreWare(car->getTyreWare() - 1);
  int newD = car->getFuel()/car->getTyreWare();
  car->setDamage(newD);
}