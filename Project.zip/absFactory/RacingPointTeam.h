#ifndef RACINGPOINTTEAM_H
#define RACINGPOINTTEAM_H

#include "Team.h"

using namespace std;

class RacingPointTeam : public Team {
public:
    RacingPointTeam();
};

#endif