#include "Factory.h"

Team* Factory::createTeam() {
return NULL;
}

Vehicle** Factory::createRaceCar() {
    return NULL;
}