#include "FerrariTeam.h"

FerrariTeam::FerrariTeam() : Team("Ferrari", "1") {

}