#ifndef MERCEDESTEAM_H
#define MERVEDESTEAM_H

#include "Team.h"

using namespace std;

class MercedesTeam : public Team {
public:
    MercedesTeam();
};

#endif

