#if !defined(Compund_H)
#define Compund_H
#include <string>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include "RaceTrack.h"

using namespace std;

class Compound 
{
	private:
			RaceTrack *raceTrack;
			string weather;
	public:
			Compound(string);
			string getWeather();
			~Compound();
			//string operation();
			void setTrack(RaceTrack*);
			RaceTrack *getTrack();
			
	
	
};
#endif
