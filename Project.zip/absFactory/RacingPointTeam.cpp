#include "RacingPointTeam.h"

RacingPointTeam::RacingPointTeam() : Team("Racing Point", "1") {

}