#include "McLarenTeam.h"

McLarenTeam::McLarenTeam() : Team("McLaren", "1") {

}