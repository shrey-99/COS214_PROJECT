#ifndef REDBULLTEAM_H
#define REDBULLTEAM_H

#include "Team.h"

using namespace std;

class RedbullTeam : public Team {
public:
    RedbullTeam();
};

#endif