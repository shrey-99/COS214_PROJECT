#include "AlphaRomeoTeam.h"

AlphaRomeoTeam::AlphaRomeoTeam() : Team("Alpha Romeo", "1") {

}