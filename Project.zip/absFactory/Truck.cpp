#include "Truck.h"
#include <iostream>

Truck::Truck() 
{
    //cout << "The truck transports the vehicles" << endl;
}