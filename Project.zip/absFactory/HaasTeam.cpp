#include "HaasTeam.h"

HaasTeam::HaasTeam() : Team("Haas", "1") {

}