#include "Soft.h"

Soft ::Soft():Compound("sunny")
{
	cout<<"Creating a Soft raceTrack "<<endl;
	RaceTrack* rt=new BasicRaceTrack();
	setTrack(rt);
}

Soft :: ~Soft()
{
}

/*
string Soft :: operation()
{
   //return this->getTrack()->operation()+"Blue";
	return "";
}*/
