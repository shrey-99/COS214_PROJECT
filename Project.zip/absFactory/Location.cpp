#include "Location.h"
#include <string>
#include <stdlib.h>
#include <time.h>
#include <iostream>


Location::Location(string wc, string ln)
{
	weatherCondition=wc;
	locationName=ln;
	 trackInformation =new Decorator();
	trackInformation->makeRaceTrack();
	trackInformation->makeCompound(wc);
	
    
   
}

Location::~Location()
{
    
    delete trackInformation;
    cout << "Location Destroyed." << endl;
}


string Location:: getRaceTrackName()
{
	return trackInformation->getRaceTrackName();
	
}


string  Location:: getTyreCompound()
{
	return trackInformation->getTyreCompound();
	
}
			
string  Location:: getWeatherCondition()
{
	return weatherCondition;
}

string  Location::getLocationName()
{
	return locationName;
	
}