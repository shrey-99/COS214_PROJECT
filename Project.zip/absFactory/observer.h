#ifndef OBSERVER_H
#define OBSERVER_H

#include <string>
class Vehicle;
using namespace std;

class observer {
public:
    virtual void checkVehicle();
    virtual void getcar(Vehicle*);

};

#endif
