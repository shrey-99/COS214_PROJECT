#include "WilliamsTeam.h"

WilliamsTeam::WilliamsTeam() : Team("Williams", "1") {

}