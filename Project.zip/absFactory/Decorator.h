#if !defined(Decorator_H)
#define Decorator_H
#include <string>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include "RaceTrack.h"
#include "Soft.h"
#include "Meduim.h"
#include "Hard.h"
#include "BasicRaceTrack.h"
#include "Compound.h"

using namespace std;

class Decorator
{
	private:
			RaceTrack *racetrack;
			Compound * c;
	public:
			Decorator();
			~Decorator();
			void makeCompound(string);
			void useCompound();
			void makeRaceTrack();
			void print();
			string getRaceTrackName();
			string getTyreCompound();
};
#endif