#include "RenaultTeamCreator.h"
#include "RenaultTeam.h"
#include "RaceCar.h"
#include <string>
#include <stdlib.h>
#include <time.h>
#include <iostream>

Team* RenaultTeamCreator::createTeam() {
	// TODO - implement RenaultTeamCreator2::createTeam
	return new RenaultTeam();
}

Vehicle** RenaultTeamCreator::createRaceCar() {
	// TODO - implement RenaultTeamCreator2::createRaceCar
	Vehicle** cars= new Vehicle*[2];
	srand (time(NULL));
	int random1=rand() % 101;
	int random2=rand() % 51;
	int random3=rand() % 30;
	int random4=rand() % 50;
	cars[0] = new RaceCar(random1, "NULL", random2, random3, random4);
	cars[1] = new RaceCar(random1, "NULL", random2, random3, random4);
	return cars;
}
