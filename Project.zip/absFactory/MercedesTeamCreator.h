#ifndef MERCEDESTEAMCREATOR_H
#define MERCEDESTEAMCREATOR_H

#include "Factory.h"
#include "Vehicle.h"
#include "Team.h"

class MercedesTeamCreator : public Factory {


public:
	Team* createTeam();

	Vehicle** createRaceCar();
};

#endif
