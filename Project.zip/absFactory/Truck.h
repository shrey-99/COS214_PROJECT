#ifndef TRUCK_H
#define TRUCK_H
#include "Vehicle.h"
using namespace std;

class Truck : public Vehicle 
{
	public:
		Truck();
};

#endif