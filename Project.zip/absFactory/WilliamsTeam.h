#ifndef WILLIAMSTEAM_H
#define WILLIAMSTEAM_H

#include "Team.h"

using namespace std;

class WilliamsTeam : public Team {
public:
    WilliamsTeam();
};

#endif