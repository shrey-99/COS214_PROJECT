#include "observer.h"

 void observer:: checkVehicle()
 {
 }
void observer::getcar(Vehicle* v)
 {
 }
