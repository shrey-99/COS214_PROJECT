#include "MercedesTeam.h"

MercedesTeam::MercedesTeam() : Team("Mercedes", "1") {

}

