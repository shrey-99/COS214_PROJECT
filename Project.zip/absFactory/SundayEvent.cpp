#include "SundayEvent.h"

SundayEvent::SundayEvent(string name) : Event(name) {
    context = new RacingLights();
    //start = new Command();
    //end = new Command();
}

SundayEvent::SundayEvent(string name, Command* s, Command* e) : Event(name) {
    context = new RacingLights();
    start = s;
    end = e;
}

void SundayEvent::performEvent() {
    this->startRace();
}

void SundayEvent::race() {
    cout << "The race has begun!" << endl;

    /*
		* Need a "node" class to store each driver and its position.
			* The drivers need to already be in the "array of nodes"
			  b4 the for loop even starts

		* Driver points stored in the driver class
		* Using lap times to differentiate between different drivers postions
		* Gonna sort the drivers by smallest lap times
			* smallest lap time wins
    */

    //1. Get the total # of Drivers in the race
    //i.e total num of drivers = # of teams x 2
	    int total_num_drivers;
	    total_num_drivers = teams.size()*2  ;

    //2. Create an Aggregate that stores all the drivers and their details
	    DynamicArray* myDynamicArray = new DynamicArray(total_num_drivers);

	//3. Store assign a driver to each node in the aggregate
	    for (int i = 0; i < teams.size(); i++){
			myDynamicArray->insert( i*2, new RaceResultNode(teams.at(i)->getDriverAt(0), teams.at(i)->getCarAt(0)) );
			myDynamicArray->insert( (i*2)+1, new RaceResultNode(teams.at(i)->getDriverAt(1), teams.at(i)->getCarAt(1)) );
	    }

	//4.Create an iterator to traverse the aggregate
		ConcreteIterator* iterator = myDynamicArray->createIterator();

    //5. da actual simulation - 20 laps
	    for (int i = 0; i < 20; ++i)
	    {
		    for(; iterator->hasNext(); iterator->next())
		    {
			    //5.1 "update tyreWare"
					iterator->updateTyreWare();

			    //5.2 "update fuel"
					iterator->updateFuel();

			    //5.3 Calculate and set lap time
					iterator->calculateLapTime();

			    //5.4 move to next driver in race
	    	}
		
		if(i%6==0)//Go to PitStop
		{
			cout << "//////////////////////////////////////////////////////////////////////////////////////////" << endl;
			cout<<"Drivers Have Completed "<<i<<" Number Of Laps"<<endl;
			cout<<"Black Flag : Return To PitStop."<<endl;
			cout << "//////////////////////////////////////////////////////////////////////////////////////////" << endl;
			vector<Team*>holder1=getTeam();
			for (auto it : holder1) 
				{ 
					PitCrew* holder=it->getPit();
					holder->getcar((RaceCar*)(it->getCarAt(0)));
					holder->checkVehicle();
					holder->refuel();
					holder->changeTyre();
					
					holder->getcar((RaceCar*)(it->getCarAt(1)));
					holder->checkVehicle();
					holder->refuel();
					holder->changeTyre();
					
	
			} 
			
		}
	    }

	//6. Sort the aggregate according to lap time
  myDynamicArray->sort();

  //7. Print the results
	cout<<"****************************************************************************************************************************"<<endl;
	cout<<"Processing Your Results."<<endl;
	cout<<"****************************************************************************************************************************"<<endl;
  	for (iterator->first();iterator->hasNext(); iterator->next())
  	{
  		iterator->printCurrent();
  	}
	cout<<"****************************************************************************************************************************"<<endl;
	cout<<"Results Processed."<<endl;
	cout<<"****************************************************************************************************************************"<<endl;
	iterator2=iterator;
    endRace();
}

void SundayEvent::startRace()
{
	cout << "                               " << endl;
	cout << "                               " << endl;
	cout << "//////////////////////////////////////////////////////////////////////////////////////////" << endl;
	 cout << "Lets Begin The Sunday Event." << endl;
	cout << "Green Flag Waved : Start Race."<< endl;
	context->setState(new RedLight("Red"));
	 context->displayCurrentLight();
	context->changeState();
	context->displayCurrentLight();
	context->changeState();
	context->displayCurrentLight();
	cout << "//////////////////////////////////////////////////////////////////////////////////////////" << endl;
	//start->execute();
	//context->setState(new GreenLight());
	context->automaticStateChange(); // should change state to green light state from initial red light state.
	

	race();
}

void SundayEvent::endRace()
{
	cout << "                               " << endl;
	cout << "                               " << endl;
	cout << "//////////////////////////////////////////////////////////////////////////////////////////" << endl;
	 cout << "Lets End The Sunday Event." << endl;
	cout << "Checkered Flag Waved : End Race."<< endl;
	context->setState(new RedLight("red"));
	 context->displayCurrentLight();
	cout << "we have reached the end of the race." << endl;
	cout << "//////////////////////////////////////////////////////////////////////////////////////////" << endl;
	//end->execute();
	//context->automaticStateChange(); // should change state to red light state from current green light state.
 
}

void SundayEvent:: printIterator()
{
	for (iterator2->first();iterator2->hasNext(); iterator2->next())
  	{
		iterator2->printCurrent();
  	}
	
}
