#include <string>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include "Non_EuropeanGrandPrix.cpp"
#include "EuropeanGrandPrix.cpp"
#include "GrandPrix.cpp"
#include "Location.cpp"
#include "Team.cpp"
#include "FridayEvent.cpp"
#include "SaturdayEvent.cpp"
#include "SundayEvent.cpp"
#include "Event.cpp"
#include "Strategist.cpp"
#include "Engineer.cpp"
#include "Driver.cpp"
#include "RacingLights.cpp"
#include "GreenLight.cpp"
#include "YellowLight.cpp"
#include "RedLight.cpp"
#include "State.cpp"
#include "Strategy.cpp"
#include "HardTyreSunnyClimateStrategy.cpp"
#include "MediumTyreCloudyClimateStrategy.cpp"
#include "SoftTyreRainyClimateStrategy.cpp"
#include "AlphaRomeoTeamCreator.cpp"
#include "AlphaTauriTeamCreator.cpp"
#include "FerrariTeamCreator.cpp"
#include "HaasTeamCreator.cpp"
#include "McLarenTeamCreator.cpp"
#include "RacingPointTeamCreator.cpp"
#include "RedBullTeamCreator.cpp"
#include "RenaultTeamCreator.cpp"
#include "WilliamsTeamCreator.cpp"
#include "RaceCar.cpp"
#include "Vehicle.cpp"
#include "AlphaRomeoTeam.cpp"
#include "AlphaTauriTeam.cpp"
#include "FerrariTeam.cpp"
#include "HaasTeam.cpp"
#include "McLarenTeam.cpp"
#include "RacingPointTeam.cpp"
#include "RedBullTeam.cpp"
#include "RenaultTeam.cpp"
#include "WilliamsTeam.cpp"
#include "Decorator.cpp"
#include "Compound.cpp"
#include "BasicRaceTrack.cpp"
#include "RaceTrack.cpp"
#include "Soft.cpp"
#include "Meduim.cpp"
#include "Hard.cpp"
#include "DynamicArray.cpp"
#include "ConcreteIterator.cpp"
#include "LinearStructure.h"
#include "RaceResultNode.cpp"
#include "observer.cpp"
#include "PitCrew.cpp"


using namespace std;

int main()
{
	cout<<"****************************************************************************************************************************"<<endl;
	cout<<"Welcome To The Formular1 Racing Event : This Is One of Our Biggest Event So Far! Lets Begin."<<endl;
	cout<<"****************************************************************************************************************************"<<endl;
	cout<<"There Are A Total Of 21 Races On 5 Different Continents."<<endl;
	cout<<"The Races Will Be Divided Between European And Non-European Races Based On Their Locations."<<endl;
	//initializing the locations for the races
	cout<<"****************************************************************************************************************************"<<endl;
	Location* location1 =new Location("sunny","Cape Town Grand Prix, South Africa");
	Location* location2 =new Location("rainy","Autodromo Enzo e Dino Ferrari, Imola, Italy");
	Location* location3 =new Location("rainy","Interlagos, S�o Paulo, Brazil");
	Location* location4 =new Location("cloudy","Circuit de Spa-Francorchamps, Spa, Belgium");
	Location* location5 =new Location("sunny","Nordschleife, N�rburg, Germany");
	cout<<"****************************************************************************************************************************"<<endl;
	cout<<"We Will Begin With Non-European Races."<<endl;
	cout<<"We need to Deliver All Necessary Equiptment, Tools And Cars To The Chosen Locations."<<endl;
	cout<<"Transporting Equiptment and Delivering Cars To: "<<endl;
	cout<<location1->getLocationName()<<endl;
	cout<<location3->getLocationName()<<endl;
	cout<<"The First 11 Races Will Be In Non-European Loaction And Will Be The First Season Of The Racing Event. "<<endl;
	cout<<"In Total We Have 10 Teams Who Will Be Participating In Each Race."<<endl;
	//create the (race) GrandPrix
	GrandPrix* Race=NULL;
	GrandPrix* Race2=NULL;
	srand (time(NULL));
	int random=rand() % 2;
	for(int i=0;i<1;i++)
	{
		if(Race!=0)
		{
			delete Race;
			Race=0;
			if(random==1)
			{
				Race= new Non_EuropeanGrandPrix(location1);
				Race->race();
			}
			else
			{
				Race= new Non_EuropeanGrandPrix(location3);
				Race->race();
			}
		}
		else
		{
			if(random==2)
			{
				Race= new Non_EuropeanGrandPrix(location1);
				Race->race();
			}
			else
			{
				Race= new Non_EuropeanGrandPrix(location3);
				Race->race();
			}
		}
		
		 random=rand() % 3;
		
	}
	cout<<"****************************************************************************************************************************"<<endl;
	cout<<"Complete With The Non-European Races."<<endl;
	cout<<"****************************************************************************************************************************"<<endl;
	cout<<"We Will Begin With European Races."<<endl;
	cout<<"We need to Deliver All Necessary Equiptment, Tools And Cars To The Chosen Locations."<<endl;
	cout<<"Transporting Equiptment and Delivering Cars To: "<<endl;
	cout<<location2->getLocationName()<<endl;
	cout<<location4->getLocationName()<<endl;
	cout<<location5->getLocationName()<<endl;
	cout<<"The Last 10 Races Will Be In European Loaction And Will Be The Second Season Of The Racing Event. "<<endl;
	cout<<"In Total We Have 10 Teams Who Will Be Participating In Each Race."<<endl;
	
	random=rand() % 4;
	for(int i=0;i<1;i++)
	{
		if(Race2!=0)
		{
			delete Race2;
			Race2=0;
			if(random==1)
			{
				Race2= new EuropeanGrandPrix(location3);
				Race2->race();
			}
			else if(random==2)
			{
				Race2= new EuropeanGrandPrix(location4);
				Race2->race();
			}
			else
			{
				Race2= new EuropeanGrandPrix(location5);
				Race2->race();
			}
		}
		else
		{
			if(random==0)
			{
				Race2= new EuropeanGrandPrix(location3);
				Race2->race();
			}
			else if(random==2)
			{
				Race2= new EuropeanGrandPrix(location4);
				Race2->race();
			}
			else
			{
				Race2= new EuropeanGrandPrix(location5);
				Race2->race();
			}
		}
		
		 random=rand() % 3;
		
	}
	
	
	cout<<"****************************************************************************************************************************"<<endl;
	cout<<"Complete With The European Races."<<endl;
	cout<<"****************************************************************************************************************************"<<endl;
	
	
	cout<<"****************************************************************************************************************************"<<endl;
	cout<<"Grand Prix Completed!!."<<endl;
	cout<<"****************************************************************************************************************************"<<endl;

    return 0;
}