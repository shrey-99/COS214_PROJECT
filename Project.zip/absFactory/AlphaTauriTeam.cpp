#include "AlphaTauriTeam.h"

AlphaTauriTeam::AlphaTauriTeam() : Team("AlphaTauri", "1") {

}