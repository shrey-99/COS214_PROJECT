#ifndef GRANDPRIX_H
#define GRANDPRIX_H

#include <string>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <vector>
#include "Location.h"
#include "Event.h"
#include "RacingLights.h"
#include "Factory.h"
#include "Vehicle.h"
#include "RaceCar.h"
#include "Team.h"
#include "AlphaRomeoTeamCreator.h"
#include "AlphaTauriTeamCreator.h"
#include "FerrariTeamCreator.h"
#include "HaasTeamCreator.h"
#include "McLarenTeamCreator.h"
#include "MercedesTeamCreator.h"
#include "RacingPointTeamCreator.h"
#include "RedBullTeamCreator.h"
#include "RenaultTeamCreator.h"
#include "WilliamsTeamCreator.h"
#include "SundayEvent.h"
#include "SaturdayEvent.h"
#include "FridayEvent.h"


using namespace std;

class GrandPrix
{
	private:
		Location* location;
		Event** events;
		string flags[8];
	
	public:
		GrandPrix();
		~GrandPrix();
		void setLocation(Location*);
		virtual void race()=0;
		Event** getEvents();
		string FlagAt(int);
};

#endif