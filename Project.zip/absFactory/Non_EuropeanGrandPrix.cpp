#include "Non_EuropeanGrandPrix.h"

Non_EuropeanGrandPrix::Non_EuropeanGrandPrix(Location*location)
{
	this->setLocation(location);
}

Non_EuropeanGrandPrix:: ~Non_EuropeanGrandPrix() 
{
}

void Non_EuropeanGrandPrix :: race()
{
	Event** events= getEvents();
	for(int x=0;x<3;x++)
	{
		events[x]->performEvent();
	}
}
