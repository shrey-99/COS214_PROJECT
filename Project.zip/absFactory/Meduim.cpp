#include "Meduim.h"



Medium :: Medium():Compound("rainy")
{
	cout<<"Creating a Medium raceTrack"<<endl;
	RaceTrack* rt=new BasicRaceTrack();
	setTrack(rt);
}
Medium :: ~Medium()
{
}
/*
string Medium :: operation()
{
	//return this->getTrack()->operation()+" Green";
	return "";
}
*/