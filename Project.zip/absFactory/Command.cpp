#include "Command.h"


Command::Command(string s) // constructor 
{
	//receiver = r;
}
Command::Command(Vehicle* r) // constructor 
{
	receiver = r;
}

Command::~Command() // virtual 
{
	
}

Vehicle* Command::getReceiver() 
{
	return receiver;
}
