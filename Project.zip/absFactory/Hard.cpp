#include "Hard.h"


Hard :: Hard():Compound("cloudy")
{
	cout<<"Creating the Hard raceTrack"<<endl;
	RaceTrack* rt=new BasicRaceTrack();
	setTrack(rt);
}
Hard ::~Hard()
{
	
}
/*string Hard ::operation()
{
	//return this->getTrack()->operation()+" Purple";
	return "";
}*/
