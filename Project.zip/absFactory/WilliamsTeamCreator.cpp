#include "WilliamsTeamCreator.h"
#include "WilliamsTeam.h"
#include "RaceCar.h"

Team* WilliamsTeamCreator::createTeam() {
	// TODO - implement WilliamsTeamCreator2::createTeam
	return new WilliamsTeam();
}

Vehicle** WilliamsTeamCreator::createRaceCar() {
	// TODO - implement WilliamsTeamCreator2::createRaceCar
	Vehicle** cars= new Vehicle*[2];
	cars[0] = new RaceCar(100, "NULL", 50, 30, 50);
	cars[1] = new RaceCar(100, "NULL", 50, 30, 50);
	return cars;
}
