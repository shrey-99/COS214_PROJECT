#include "EuropeanGrandPrix.h"

EuropeanGrandPrix::EuropeanGrandPrix(Location* location) 
{
	this->setLocation(location);
}

EuropeanGrandPrix:: ~EuropeanGrandPrix() 
{
	
}
void EuropeanGrandPrix::race()
{
	Event** events= getEvents();
	for(int x=0;x<3;x++)
	{
		events[x]->performEvent();
	}
}

