#ifndef FERRARITEAM_H
#define FERRARITEAM_H

#include "Team.h"

using namespace std;

class FerrariTeam : public Team {
public:
    FerrariTeam();
};

#endif