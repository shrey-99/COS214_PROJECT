#include "RedbullTeam.h"

RedbullTeam::RedbullTeam() : Team("RedBull", "1") {

}